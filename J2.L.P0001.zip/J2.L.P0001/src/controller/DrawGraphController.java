/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package controller;

import entity.Coordinate;
import entity.Edge;
import entity.Graph;
import entity.LineArrow;
import entity.Vertex;
import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.util.List;

/**
 * define class DrawGraphController
 *
 * @author Kien Nguyen
 */
public class DrawGraphController extends Canvas {

    Graph graph;

    public DrawGraphController() {
        graph = null;
    }

    public DrawGraphController(Graph graph) {
        this.graph = graph;
    }

    public Graph getGraph() {
        return graph;
    }

    public void setGraph(Graph graph) {
        this.graph = graph;
    }

    @Override
    public void paint(Graphics g) {
        g.create();
        initGraphics(g);
        if (graph != null) {
            analyzeDrawing((Graphics2D) g);
        }
    }

    /**
     * initiate graphics for canvas
     *
     * @param g
     */
    private void initGraphics(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setBackground(Color.WHITE);
        g2.clearRect(0, 0, this.getWidth(), this.getHeight());
    }

    /**
     * draw all elements in graph
     *
     * @param g2
     */
    public void analyzeDrawing(Graphics2D g2) {
        setSizeForVertex(g2, graph.getListVertex());
        drawVertex(g2, graph.getListVertex());
        drawLinksBetweenVertexs(g2, graph.getListEdges());
        drawLabelOfArrow(g2, graph.getListEdges());
    }

    /**
     * Draw vertex
     *
     * @param g2
     * @param vertices
     */
    public void drawVertex(Graphics2D g2, List<Vertex> vertices) {

        for (Vertex vertice : vertices) {
            int size = vertice.getSizeOfVertex();
            System.out.println(size);
            float thickness = 2;
            Stroke oldStroke = g2.getStroke();
            g2.setStroke(new BasicStroke(thickness));
            g2.setColor(vertice.getColor());
            g2.drawOval(vertice.getCoordinate().getX() - size, vertice.getCoordinate().getY() - size, 2 * size, 2 * size);
            g2.setStroke(oldStroke);
            g2.setColor(Color.BLACK);
            g2.setFont(new Font("Times New Roman", Font.BOLD, 12));
            g2.drawString(vertice.getLabel(), vertice.getCoordinate().getX() - size / 2, vertice.getCoordinate().getY() + size / 8);
        }
    }

    /**
     * draw arrow links among vertices traversal Edges: get center of
     * from-vertex, get angel of link(by coordinates), get coordinates of
     * endpoint of link, use class LineArrow to draw.
     *
     * @param g2
     * @param edges
     */
    public void drawLinksBetweenVertexs(Graphics2D g2, List<Edge> edges) {
        for (Edge edge : edges) {
            g2.setStroke(new BasicStroke(2));

            Vertex centerOfVertexTo = graph.getVertexByLabel(edge.getToVertex());
            Vertex centerOfVertexFrom = graph.getVertexByLabel(edge.getFromVertex());
            // get begin point's coordinate
            Coordinate coorFromV = graph.getCoordinatesByVertexLabel(edge.getFromVertex());
            //get end point's coordinate
            Coordinate coorToV = graph.getCoordinatesByVertexLabel(edge.getToVertex());

            //angle to get begin, end coordinate of line arrow
            double angle = Math.atan2(coorToV.getY() - coorFromV.getY(), coorToV.getX() - coorFromV.getX());

            //set begin point of arrow
            int x_Begin_Point = (int) (coorFromV.getX() + centerOfVertexFrom.getSizeOfVertex() * Math.cos(angle));
            int y_Begin_Point = (int) (coorFromV.getY() + centerOfVertexFrom.getSizeOfVertex() * Math.sin(angle));

            //set end point of arrow
            int x_End_Point = (int) (coorToV.getX() - centerOfVertexTo.getSizeOfVertex() * Math.cos(angle));
            int y_End_point = (int) (coorToV.getY() - centerOfVertexTo.getSizeOfVertex() * Math.sin(angle));

            LineArrow lineArrow = new LineArrow(x_Begin_Point, y_Begin_Point, x_End_Point, y_End_point, 2);
            lineArrow.draw(g2);
        }
    }

    /**
     * draw label of link traversal edges: get coordinates of from-vertex and
     * to-vertex => coordinates of cost to draw (set font...) => use drawString
     *
     * @param g2
     * @param edges
     */
    public void drawLabelOfArrow(Graphics2D g2, List<Edge> edges) {
        for (Edge edge : edges) {
            g2.setStroke(new BasicStroke(2));
            Vertex fromV = graph.getVertexByLabel(edge.getFromVertex());
            Vertex toV = graph.getVertexByLabel(edge.getToVertex());
            int xOfCost = (fromV.getCoordinate().getX() + toV.getCoordinate().getX()) / 2;
            int yOfCost = (fromV.getCoordinate().getY() + toV.getCoordinate().getY()) / 2;
            String cost = edge.getLabel();
            g2.setFont(new Font("Times New Roman", Font.BOLD, 13));
            g2.drawString(cost, xOfCost, yOfCost);
        }
    }

    /**
     * set size for all vertices
     *
     * @param g2
     * @param listV
     */
    public void setSizeForVertex(Graphics2D g2, List<Vertex> listV) {
        for (Vertex vertex : listV) {
            // get with by pixel of vertex
            FontMetrics fm = g2.getFontMetrics();
            int w = fm.stringWidth(vertex.getLabel());
            vertex.setSizeOfVertex(w);
        }
    }
}
