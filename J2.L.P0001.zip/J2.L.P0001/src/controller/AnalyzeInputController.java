/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package controller;

import entity.Coordinate;
import entity.Edge;
import entity.Graph;
import entity.Vertex;
import java.awt.Color;
import java.lang.reflect.Field;
import java.util.StringTokenizer;

/**
 * define class AnalyzeInputController
 * @author Kien Nguyen
 */
public class AnalyzeInputController {

    String inforGraph;
    Graph graph;

    public AnalyzeInputController() {
    }

    public AnalyzeInputController(String info) throws Exception {
        this.inforGraph = info;
        this.graph = new Graph();
        info = info.trim();
        if (info.length() == 0) {
            throw new Exception("You have not input anything\n"
                    + "Please input by form:\n"
                    + "NAME_GRAPH{\n"
                    + " vertice_name[label=\"{NOT_BLANK}\", color=\"{NOT_BLANK}\"}"
                    + "\n vertice->vertice[label=\"{NOT_BLANK}\"\n}");
        }
    }

    /**
     * get Name of Graph
     *
     * @return return name of a graph from snippet code
     */
    public String getNameGraph() throws Exception {
        StringTokenizer st = new StringTokenizer(inforGraph, "\n");
        String name = st.nextToken();
        if (name.endsWith("{")) {

            name = name.substring(0, name.length() - 1);
            if (name.contains("{") || name.contains("}")) {
                throw new Exception("Name is incorrect");
            } else {
                return name;
            }
        } else {
            throw new Exception("Line 1 is incorrect");
        }

    }

    /**
     * analyze information of a vertex: name, label, color
     *
     * @param countLine
     * @param inforVertice
     * @throws Exception syntax
     * @return a vertex
     */
    private Vertex analyzeVertex(int countLine, String inforVertice) throws Exception {
        boolean startLabel = false;
        boolean startColor = false;
        boolean startName = false;

        String labelVertice = "", nameVertice = "", colorVertice = "";
        Color color = null;
        StringTokenizer st = new StringTokenizer(inforVertice, "\"[] ");
        //read information from string after split
        while (st.hasMoreTokens()) {
            String temp = st.nextToken();
            if (!startName) {
                nameVertice = temp;
                startName = true;
                continue;
            }
            try {
                if (!startLabel && temp.contains("label")) {
                    labelVertice = st.nextToken();
                    startLabel = true;
                    continue;
                }
                if (!startColor && temp.contains("color")) {
                    colorVertice = st.nextToken();
                    startColor = true;
                    Field field = Class.forName("java.awt.Color").getField(colorVertice);
                    color = (Color) field.get(null);
                    break;
                }
            } catch (Exception e) {
                if (labelVertice.equals("") || colorVertice.equals("")) {
                    throw new Exception("Line " + countLine + "\n"
                            + "\nYour input propertise is blank.\n"
                            + "Just input vertice_name["
                            + "label=\"{NOT_BLANK}\",color=\"{NOT_BLANK}\"]");
                } else {
                    throw new Exception("Line " + countLine + "\n"
                            + "Your color is invalid");
                }
            }
        }
        return new Vertex(nameVertice, labelVertice, color, new Coordinate(),0);
    }

    /**
     * analyze information of an edge: from vertex, to vertex, label
     *
     * @param countLine line that we check
     * @param edge String that we check
     * @throws Exception syntax
     * @return an Edge
     */
    private Edge analyzeEdge(int countLine, String edge) throws Exception {
        StringTokenizer st = new StringTokenizer(edge, "\"->[] ");
        String fromVertex = "", toVertex = "", label = "";
        //read information from string after split
        while (st.hasMoreTokens()) {
            String temp = st.nextToken();
            if (fromVertex.compareTo("") == 0) {
                fromVertex = temp;
                continue;
            }
            if (toVertex.compareTo("") == 0) {
                toVertex = temp;
                continue;
            }
            try {
                if (temp.contains("label")) {
                    label = st.nextToken();
                    break;
                }
            } catch (Exception e) {
                throw new Exception("Line " + countLine + "\n"
                        + "Your input propertise is blank.\n"
                        + "Just input vertice->vertice["
                        + "label=\"{NOT_BLANK}\"]");
            }

        }
        return new Edge(label, fromVertex, toVertex);
    }

    /**
     * analyze Graph
     *
     * @return a Graph
     * @throws Exception syntax
     */
    public Graph analyzeGraph() throws Exception {
        StringTokenizer st = new StringTokenizer(inforGraph, "\n");
        int countLine = 0;
        Graph myGraph = new Graph();
        //loop all line of snippet code to read information
        while (st.hasMoreTokens()) {
            String temp = st.nextToken();
            temp = temp.trim();

            countLine++;
            //line is a comment
            if (temp.length() > 2 && temp.substring(0, 2).equals("//")) {
                continue;
            }
            if (temp.endsWith("]")) {
                //a line is about vertice if has label and color
                if (temp.contains("label=\"") && temp.contains(",color=\"")) {
                    myGraph.addVertex(analyzeVertex(countLine, temp));
                } //a line is about edge if has label
                else if (temp.contains("label=\"") && !temp.contains(",color=\"")) {
                    myGraph.addEdge(analyzeEdge(countLine, temp));
                } else {
                    throw new Exception("Line " + countLine + ""
                            + "\nInvalid syntax: " + temp);
                }

            } else {
                //not valid line
                if (temp.length() != 0 && !temp.contains(getNameGraph()) && !temp.equals("}")) {
                    throw new Exception("Line " + countLine + ""
                            + "\nInvalid syntax: " + temp);
                }
            }
        }
        return myGraph;
    }

}
