/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author Kien Nguyen
 */
public class FileController {

    /**
     * get File Content
     *
     * @param filePath path of file
     * @return a string
     */
    public String getFileContent(String filePath) {
        String fileContent = "";
        try {
            Scanner scanner = new Scanner(new FileReader(filePath));
            while (scanner.hasNext()) {
                fileContent += scanner.nextLine() + "\n";
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Error in getFileContent: " + ex.getMessage());
        }
        return fileContent;
    }

    /**
     * Save file in to a path
     *
     * @param path path of this file
     * @param content content of file
     */
    public void saveFile(String path, String content) {
        try {
            FileWriter fw = new FileWriter(path);
            fw.write(content);
            fw.close();
        } catch (Exception e) {
            System.out.println("Error in saveFile: " + e.getMessage());
        }
    }
}
