/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package entity;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.AffineTransform;

/**
 *
 * @author Kien Nguyen
 */
public class LineArrow {

    int xPoly[] = {0, -5, 5};
    int yPoly[] = {0, -10, -10};

    Polygon arrow = new Polygon(xPoly, yPoly, xPoly.length);
    int x; // x-coordinate of begin vertex
    int y; // y-coordinate of begin vertex
    int endX;  // x-coordinate of end vertex
    int endY; // y-coordinate of end vertex
    int thickness;

    public LineArrow(int x, int y, int x2, int y2, int thickness) {
        this.x = x;
        this.y = y;
        this.endX = x2;
        this.endY = y2;
        this.thickness = thickness;
    }

    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;

        // Calculate the angle of the arrow.
        double angle = Math.atan2(endY - y, endX - x);

        g2.setStroke(new BasicStroke(thickness));

        // Draw the line. Crops 10 pixels at the tip so the tip doesn't get thick.
        g2.drawLine(x, y, (int) (endX - 10 * Math.cos(angle)), (int) (endY - 10 * Math.sin(angle)));

        // Get the original AffineTransform.
        AffineTransform tx1 = g2.getTransform();

        // Create a copy of AffineTransform.
        AffineTransform tx2 = (AffineTransform) tx1.clone();

        // Translate and rotate the new AffineTransform.
        tx2.translate(endX, endY);
        tx2.rotate(angle - Math.PI / 2);

        // Draw the tip with the AffineTransform translated and rotated.
        g2.setTransform(tx2);
        g2.fill(arrow);
        g2.setTransform(tx1);
    }
}
