/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package entity;

/**
 * define class edge
 *
 * @author Kien Nguyen
 */
public class Edge {
    
    //label of edge
    private String label;
    //start vertex of this edge
    private String fromVertex;
    //end vertex of this edge
    private String toVertex;

    public Edge() {
    }
    
    public Edge(String label, String fromVertex, String toVertex) {
        this.label = label;
        this.fromVertex = fromVertex;
        this.toVertex = toVertex;
    }

    public String getFromVertex() {
        return fromVertex;
    }

    public void setFromVertex(String fromVertex) {
        this.fromVertex = fromVertex;
    }

    public String getToVertex() {
        return toVertex;
    }

    public void setToVertex(String toVertex) {
        this.toVertex = toVertex;
    }
    

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return "Edge{" + "label=" + label + ", fromVertex=" + fromVertex + ", toVertex=" + toVertex + '}';
    }

}
