/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package entity;

import java.util.ArrayList;
import java.util.List;

/**
 * define class Graph
 *
 * @author Kien Nguyen
 */
public class Graph {

    private String name;
    // list edges of the graph
    private List<Edge> listEdges;
    //list vertex of the graph
    private List<Vertex> listVertex;

    public Graph() {
        this.name = "";
        this.listEdges = new ArrayList<Edge>();
        this.listVertex = new ArrayList<Vertex>();
    }

    /**
     * Constructor class Graph
     *
     * @param name
     * @param listEdges
     * @param listVertex
     */
    public Graph(String name, List<Edge> listEdges, List<Vertex> listVertex) {
        this.name = name;
        this.listEdges = listEdges;
        this.listVertex = listVertex;
        setCoordinateForListVertex();
    }

    /**
     * get List Edges
     *
     * @return list Edges
     */
    public List<Edge> getListEdges() {
        return listEdges;
    }

    public void setListEdges(List<Edge> listEdges) {
        this.listEdges = listEdges;
    }

    public List<Vertex> getListVertex() {
        return listVertex;
    }

    public void setListVertex(List<Vertex> listVertex) {
        this.listVertex = listVertex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Graph{" + "name=" + name + ",\nlistEdges=" + listEdges + ",\n listVertex=" + listVertex + '}';
    }

    /**
     * add new Edge to Graph
     *
     * @param newEdge
     */
    public void addEdge(Edge newEdge) {
        this.listEdges.add(newEdge);
    }

    /**
     * add new Vertex to Graph
     *
     * @param newVertex
     */
    public void addVertex(Vertex newVertex) {
        listVertex.add(newVertex);
    }

    /**
     * Get Vertex by Label of this Vertex
     *
     * @param label
     * @return a vertex if exist, null otherwise
     */
    public Vertex getVertexByLabel(String label) {
        for (Vertex vertex : listVertex) {
            if (vertex.getName().equalsIgnoreCase(label)) {
                return vertex;
            }
        }
        return null;
    }

    /**
     * Get coordinate of a vertex by it's label
     *
     * @param labelVertex
     * @return a coordinate if exist, null otherwise
     */
    public Coordinate getCoordinatesByVertexLabel(String labelVertex) {
        for (Vertex vertex : listVertex) {
            if (vertex.getName().equalsIgnoreCase(labelVertex)) {
                return new Coordinate(vertex.getCoordinate().getX(), vertex.getCoordinate().getY());
            }
        }
        return null;
    }

    int X_CENTER_GRAPH = 200;
    int Y_CENTER_GRAPH = 200;
    int X_INIT_POINT = 80;
    int Y_INIT_POINT = 80;

    /**
     * set Coordinates for list Vertex
     */
    public void setCoordinateForListVertex() {
        int totalVertices = listVertex.size();
        double angleBetweenVetices = 2 * Math.PI / totalVertices;
        int count = 0;
        for (Vertex vertice : listVertex) {
            double x0 = X_INIT_POINT - X_CENTER_GRAPH;
            double y0 = Y_INIT_POINT - Y_CENTER_GRAPH;
            double x = x0 * Math.cos(angleBetweenVetices * count) - y0 * Math.sin(angleBetweenVetices * count);
            double y = x0 * Math.sin(angleBetweenVetices * count) + y0 * Math.cos(angleBetweenVetices * count);
            vertice.setCoordinate(new Coordinate((int) (x + X_CENTER_GRAPH), (int) (y + Y_CENTER_GRAPH)));
            count++;
        }
    }
}
