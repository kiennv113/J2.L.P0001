/*
 Title:            Simple Graph Visualization Software (sGraphviz)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package entity;

import java.awt.Color;
import java.util.List;

/**
 * define class Vertex
 *
 * @author Kien Nguyen
 */
public class Vertex {

    //name of vertex
    private String name;
    //label of vertex
    private String label;
    //color of vertex
    private Color color;
    //coordinate of vertex
    Coordinate coordinate;
    //size of vertex
    int sizeOfVertex;

    public Vertex() {
        this.name = "";
        this.label = "";
        this.color = null;
        this.coordinate = null;
        this.sizeOfVertex = 0;
    }

    public Vertex(String name, String label, Color color, Coordinate coordinate, int sizeOfVertex) {
        this.name = name;
        this.label = label;
        this.color = color;
        this.coordinate = coordinate;
        this.sizeOfVertex = sizeOfVertex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(Coordinate coordinate) {
        this.coordinate = coordinate;
    }

    public int getSizeOfVertex() {
        return sizeOfVertex;
    }

    public void setSizeOfVertex(int sizeOfVertex) {
        this.sizeOfVertex = sizeOfVertex;
    }

    @Override
    public String toString() {
        return "Vertex{" + "name=" + name + ", label=" + label + ", color=" + color + ", coordinate=" + coordinate + ", sizeOfVertex=" + sizeOfVertex + '}';
    }



}
